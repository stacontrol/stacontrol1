
# Stacontrol Cloud Redesign

Bu depo, ETABS + comtypes bağımlılığını sadece istemci tarafına (Windows ajanı) taşıyarak
bulutta platformdan bağımsız bir Streamlit + FastAPI çözümü sunar.

## Yapı

```
stacontrol-cloud/
  agent/              # Windows'ta çalışan ETABS ajanı
    agent.py
    requirements.txt
  server/             # FastAPI JSON API'si
    main.py
    requirements.txt
  viewer/             # Streamlit paneli (sunucudan veri çeker)
    viewer.py
```

### Agent
1. Windows + ETABS yüklü bilgisayarda `pip install -r requirements.txt`.
2. `python agent.py --project-id myproj --server https://<SUNUCU_IP>:8000`.
3. Script ETABS'i açıp verileri gönderecek.
4. `pyinstaller --onefile agent.py` ile tek dosyalık EXE oluşturabilirsiniz.

### Server
1. Linux/Windows bulut makinenizde `pip install -r requirements.txt`.
2. `uvicorn main:app --host 0.0.0.0 --port 8000`.

### Viewer
1. `pip install streamlit pandas requests`.
2. `streamlit run viewer.py`.

Bu temel sürümdür; diğer tabloların export fonksiyonlarını (kolon/perde kapasite vb.)
`agent.py` içinde yer alan TODO alanlarına ekleyebilirsiniz.
