
"""
Stacontrol Windows Agent
------------------------
Küçük, tek dosyalık bir Python betiği/EXE'si olarak çalışır.
1. ETABS OAPI'ye bağlanır (comtypes).
2. Seçilen verileri JSON formatına çevirir.
3. REST API (FastAPI) yoluyla bulut sunucusuna gönderir.

Çıktı şeması örneği:
{
    "project_id": "my-project",
    "export_time": "2025-06-30T12:00:00+03:00",
    "story_drifts": [...],
    "column_capacities": [...],
    ...
}
"""
import argparse, json, os, sys, uuid, requests, datetime

try:
    import comtypes.client as cc
except ImportError:
    sys.exit("Bu ajan yalnızca Windows + ETABS kurulu makinelerde çalışır (comtypes bulunamadı).")

def connect_etabs():
    """ETABS objesine bağlanır veya başlatır"""
    try:
        etabs = cc.GetActiveObject("CSI.ETABS.API.ETABSObject")
    except Exception:
        etabs = cc.CreateObject("CSI.ETABS.API.ETABSObject")
        etabs.ApplicationStart()
    return etabs

def export_story_drifts(SapModel):
    """Story Drifts tablosunu DataFrame karşılığı bir liste‑sözlük yapısına çevirir"""
    TableKey = "Story Drifts"
    ret = SapModel.DatabaseTables.GetTableForDisplayArray(TableKey)
    if ret[0] != 0:
        raise RuntimeError("Tablo okunamadı")
    field_names = ret[1]
    values = ret[-1]
    n_fields = len(field_names)
    records = [values[i:i+n_fields] for i in range(0, len(values), n_fields)]
    return [dict(zip(field_names, r)) for r in records]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-id", required=True, help="Proje veya model adı")
    ap.add_argument("--server", required=True, help="Bulut API kök URL'si, örn. https://stacontrol.my.domain")
    ap.add_argument("--token", help="(Opsiyonel) Bearer auth token")
    args = ap.parse_args()

    etabs = connect_etabs()
    SapModel = etabs.SapModel

    payload = {
        "project_id": args.project_id,
        "export_time": datetime.datetime.now().isoformat(),
        "story_drifts": export_story_drifts(SapModel),
        # TODO diğer tablo çağrılarını ekle
    }

    headers = {"Content-Type": "application/json"}
    if args.token:
        headers["Authorization"] = f"Bearer {args.token}"
    r = requests.post(args.server.rstrip('/') + "/upload", json=payload, timeout=60, headers=headers)
    if r.status_code == 201:
        print("✅ Veri başarıyla yüklendi.")
    else:
        print(f"❌ Sunucu hatası: {r.status_code} – {r.text}")
        sys.exit(1)

if __name__ == "__main__":
    main()
