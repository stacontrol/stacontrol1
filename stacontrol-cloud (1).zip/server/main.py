
"""
Basit FastAPI sunucusu – ETABS ajanından gelen JSON'u alır ve SQLite'e yazar.
Çalıştırmak için:
    uvicorn main:app --reload --host 0.0.0.0 --port 8000
"""
import uuid, datetime, json, sqlite3, os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List, Dict, Any

DB_PATH = os.getenv("STACONTROL_DB", "stacontrol.db")

app = FastAPI(title="Stacontrol API")

class StoryDrift(BaseModel):
    Story: str
    LoadCase: str
    Direction: str
    Drift: float

class UploadPayload(BaseModel):
    project_id: str = Field(..., example="block-a")
    export_time: datetime.datetime
    story_drifts: List[Dict[str, Any]]
    # TODO diğer tablolar

def init_db():
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS uploads (
        id TEXT PRIMARY KEY,
        project_id TEXT,
        export_time TEXT,
        json TEXT
    )
    """)
    con.commit()
    con.close()

init_db()

@app.post("/upload", status_code=201)
def upload(payload: UploadPayload):
    uid = str(uuid.uuid4())
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute(
        "INSERT INTO uploads (id, project_id, export_time, json) VALUES (?, ?, ?, ?)",
        (uid, payload.project_id, payload.export_time.isoformat(), payload.json())
    )
    con.commit()
    con.close()
    return {"id": uid}

@app.get("/projects")
def list_projects():
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute("SELECT DISTINCT project_id FROM uploads")
    rows = [r[0] for r in cur.fetchall()]
    con.close()
    return rows

@app.get("/data/{upload_id}")
def get_upload(upload_id: str):
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute("SELECT json FROM uploads WHERE id = ?", (upload_id,))
    row = cur.fetchone()
    con.close()
    if not row:
        raise HTTPException(status_code=404, detail="Upload not found")
    return json.loads(row[0])
