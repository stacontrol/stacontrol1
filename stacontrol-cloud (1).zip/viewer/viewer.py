
import streamlit as st
import pandas as pd
import requests

st.set_page_config(page_title="Stacontrol Viewer", layout="wide")

st.title("Stacontrol – Sunucu Verileri")

api_url = st.text_input("API URL", "http://localhost:8000")

if st.button("Projeleri Getir"):
    try:
        projects = requests.get(f"{api_url}/projects", timeout=10).json()
        st.success("Projektler yüklendi")
        st.write(projects)
    except Exception as e:
        st.error(str(e))

upload_id = st.text_input("Upload ID")
if st.button("Veriyi Getir"):
    if upload_id:
        try:
            data = requests.get(f"{api_url}/data/{upload_id}", timeout=10).json()
            st.write("**Story Drifts**")
            st.dataframe(pd.DataFrame(data["story_drifts"]))
        except Exception as e:
            st.error(str(e))
